================================================
*****SimpleStopwatch*****
================================================
Author: Shyamal Anadkat
Class: 454, Minilab-2
================================================
- Contents of submission: Stopwatch.java, MainActivity.java
- To run: Install the app on an android device
- START, PAUSE/RESUME, and RESET timer functionality incorporated 
- Intuitive interface + non-UI thread incorporated
================================================
> Questions can be directed to anadkat@wisc.edu
================================================