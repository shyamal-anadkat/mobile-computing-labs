================================================
Shyamal H Anadkat
================================================
Implementation Notes: 
- Step counter impl using Acc. magnitude values (pretty accurate)
- Compared to stepcounter/stepdetector sensor values 
- Direction using ORIENTATION sensor
================================================